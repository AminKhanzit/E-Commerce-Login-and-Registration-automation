import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;


import java.time.Duration;

public class Setup {

    WebDriver driver;

    // This method runs before testing Started
    @BeforeTest
    public void setup() {
        // Open a Chrome browser window
        driver = new ChromeDriver();

        //browser window larger
        driver.manage().window().maximize();

        // Wait up to 30 seconds
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        // Open the Website
        driver.get("https://opensource-demo.orangehrmlive.com/");
    }

    // This method will close the browser after tests
    @AfterMethod
    public void ExitBrowser() {
        // Close the browser and free up resources
        driver.quit();
    }
}
