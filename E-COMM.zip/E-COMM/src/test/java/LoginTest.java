import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginTest {
    @FindBy(name = "username")
    WebElement txtUsername;
    @FindBy(name = "email")
    WebElement txtEmail;
    @FindBy(name = "password")
    WebElement txtPassword;
    @FindBy(css = "[type=submit]")
    WebElement btnSubmit;
    public LoginTest(WebDriver driver){
        PageFactory.initElements(driver,this);
    }
    public void registration (String username, String email, String password){
        txtUsername.sendKeys(username);
        txtEmail.sendKeys(email);
        txtPassword.sendKeys(password);
        btnSubmit.click();
    }
    public void  doLogin(String username, String password){
        txtUsername.sendKeys(username);
        txtPassword.sendKeys(password);
        btnSubmit.click();
    }

}
