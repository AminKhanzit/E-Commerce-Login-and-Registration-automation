import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTestRunner extends Setup{
    @Test(priority = 1, description = "Successful Registration with valid Data")
    public void  registration (){
        LoginTest loginPage = new LoginTest(driver);
        loginPage.registration("Admin", "admin1232@test.com", "1234");
    }
    @Test(priority = 2, description = "Invalid Creds message check")
    public void properErrorMsgforInvCreds(){
        LoginTest loginPage = new LoginTest(driver);
        loginPage.doLogin("wrongUsername", "wrongPass");
        WebElement alertMsg=driver.findElement(By.className("oxd-alert oxd-alert--error"));
        Assert.assertEquals(alertMsg.getText(), "Invalid credentials");
    }
    @Test(priority = 3, description = "Login Successful")
    public void doLogin(){
        LoginTest loginPage = new LoginTest(driver);
        loginPage.doLogin("Admin", "admin123");

    }


}
